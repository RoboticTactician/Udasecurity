package com.udacity.catpoint.image.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.core.SdkBytes;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.rekognition.RekognitionClient;
import software.amazon.awssdk.services.rekognition.model.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Image Recognition Service that can identify cats using AWS Rekognition.
 * Requires AWS credentials to be entered in `config.properties` to work.
 */
public class AwsImageService implements ImageService {
    private static final Logger log = LoggerFactory.getLogger(AwsImageService.class);

    private static RekognitionClient rekognitionClient;

    public AwsImageService() {
        loadRekognitionClient();
    }

    private void loadRekognitionClient() {
        Properties props = loadPropertiesFile();

        if (props != null) {
            String awsId = props.getProperty("aws.id");
            String awsSecret = props.getProperty("aws.secret");
            String awsRegion = props.getProperty("aws.region");

            AwsCredentials awsCredentials = AwsBasicCredentials.create(awsId, awsSecret);
            rekognitionClient = RekognitionClient.builder()
                    .credentialsProvider(StaticCredentialsProvider.create(awsCredentials))
                    .region(Region.of(awsRegion))
                    .build();
        }
    }

    private Properties loadPropertiesFile() {
        Properties props = new Properties();
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("config.properties")) {
            props.load(is);
        } catch (IOException ioe) {
            log.error("Unable to initialize AWS Rekognition, no properties file found", ioe);
            return null;
        }
        return props;
    }

    public boolean imageContainsCat(BufferedImage image, float confidenceThreshold) {
        if (rekognitionClient == null) {
            log.error("Rekognition client not initialized. Image analysis not possible.");
            return false;
        }

        Image awsImage = convertImageToAWSImage(image);

        DetectLabelsRequest detectLabelsRequest = DetectLabelsRequest.builder()
                .image(awsImage)
                .minConfidence(confidenceThreshold)
                .build();

        DetectLabelsResponse response = rekognitionClient.detectLabels(detectLabelsRequest);

        logLabelsForFun(response);

        return containsCatLabel(response.labels());
    }

    private Image convertImageToAWSImage(BufferedImage image) {
        Image awsImage = null;
        try (ByteArrayOutputStream os = new ByteArrayOutputStream()) {
            ImageIO.write(image, "jpg", os);
            awsImage = Image.builder().bytes(SdkBytes.fromByteArray(os.toByteArray())).build();
        } catch (IOException ioe) {
            log.error("Error building image byte array", ioe);
        }
        return awsImage;
    }

    private void logLabelsForFun(DetectLabelsResponse response) {
        log.info(response.labels().stream()
                .map(label -> String.format("%s(%.1f%%)", label.name(), label.confidence()))
                .collect(Collectors.joining(", ")));
    }

    private boolean containsCatLabel(List<Label> labels) {
        return labels.stream()
                .anyMatch(label -> label.name().toLowerCase().contains("cat"));
    }
}
