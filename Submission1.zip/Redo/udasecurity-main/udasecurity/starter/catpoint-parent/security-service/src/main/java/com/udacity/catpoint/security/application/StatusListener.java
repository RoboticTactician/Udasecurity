package com.udacity.catpoint.security.application;

import com.udacity.catpoint.security.data.AlarmStatus;

/**
 * Identifies a component that should be notified whenever the system status changes
 */
public interface StatusListener {
    /**
     * This method is called when the system status changes.
     * It provides the new system status as an `AlarmStatus` enum.
     * @param status The new system status.
     */
    void notify(AlarmStatus status);

    /**
     * This method is called when a cat is detected in the system.
     * It indicates whether a cat has been detected.
     * @param catDetected `true` if a cat is detected, `false` otherwise.
     */
    void catDetected(boolean catDetected);

    /**
     * This method is called when the sensor status changes within the system.
     * It signifies that there has been a change in sensor statuses.
     */
    void sensorStatusChanged();
}
