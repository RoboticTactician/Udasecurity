package com.udacity.catpoint.security.application;

import com.udacity.catpoint.security.data.ArmingStatus;
import com.udacity.catpoint.security.service.SecurityService;
import com.udacity.catpoint.security.service.StyleService;
import net.miginfocom.swing.MigLayout;

import javax.swing.*;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public class ControlPanel extends JPanel {
    private SecurityService securityService;
    private Map<ArmingStatus, JButton> buttonMap;

    public ControlPanel(SecurityService securityService, SensorPanel sensorPanel) {
        super();
        setLayout(new MigLayout());
        this.securityService = securityService;

        // Create a label for the panel with a specific font style.
        JLabel panelLabel = new JLabel("System Control");
        panelLabel.setFont(StyleService.HEADING_FONT);

        // Add the label to the panel and specify layout constraints (span 3 means it spans 3 columns, "wrap" starts a new line).
        add(panelLabel, "span 3, wrap");

        // Create a map that associates each arming status with a JButton.
        buttonMap = Arrays.stream(ArmingStatus.values())
                .collect(Collectors.toMap(status -> status, status -> new JButton(status.getDescription())));

        // Add an action listener to each button, which sets the arming status, updates button colors, and refreshes the sensor list.
        buttonMap.forEach((k, v) -> {
            v.addActionListener(e -> {
                securityService.setArmingStatus(k);
                buttonMap.forEach((status, button) -> button.setBackground(status == k ? status.getColor() : null));
                sensorPanel.updateSensorList();
            });
        });

        // Add the buttons to the panel in the order defined by the ArmingStatus enum.
        Arrays.stream(ArmingStatus.values()).forEach(status -> add(buttonMap.get(status)));

        // Set the background color of the button corresponding to the current arming status.
        ArmingStatus currentStatus = securityService.getArmingStatus();
        buttonMap.get(currentStatus).setBackground(currentStatus.getColor());
    }
}
