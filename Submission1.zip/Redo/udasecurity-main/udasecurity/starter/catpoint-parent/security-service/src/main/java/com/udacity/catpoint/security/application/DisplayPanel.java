package com.udacity.catpoint.security.application;

import com.udacity.catpoint.security.data.AlarmStatus;
import com.udacity.catpoint.security.service.SecurityService;
import com.udacity.catpoint.security.service.StyleService;
import net.miginfocom.swing.MigLayout;

import javax.swing.*;

/**
 * Displays the current status of the system. Implements the StatusListener
 * interface so that it can be notified whenever the status changes.
 */
public class DisplayPanel extends JPanel implements StatusListener {
    private JLabel currentStatusLabel;

    public DisplayPanel(SecurityService securityService) {
        super();
        setLayout(new MigLayout());

        // Register this panel as a listener with the security service to receive status updates.
        securityService.addStatusListener(this);

        // Create labels for panel title, system status, and the current status.
        JLabel panelLabel = new JLabel("Very Secure Home Security");
        JLabel systemStatusLabel = new JLabel("System Status:");
        currentStatusLabel = new JLabel();

        // Set the font style for the panel title label.
        panelLabel.setFont(StyleService.HEADING_FONT);

        // Initialize the current status label with the initial status received from the security service.
        notify(securityService.getAlarmStatus());

        // Add the labels to the panel, specifying layout constraints (e.g., "span 2" means it spans 2 columns, "wrap" starts a new line).
        add(panelLabel, "span 2, wrap");
        add(systemStatusLabel);
        add(currentStatusLabel, "wrap");
    }

    @Override
    public void notify(AlarmStatus status) {
        // Update the current status label with the description and background color of the current alarm status.
        currentStatusLabel.setText(status.getDescription());
        currentStatusLabel.setBackground(status.getColor());
        currentStatusLabel.setOpaque(true);
    }

    @Override
    public void catDetected(boolean catDetected) {
        // No specific behavior is necessary for cat detection in this panel.
    }

    @Override
    public void sensorStatusChanged() {
        // No specific behavior is necessary for sensor status changes in this panel.
    }
}
