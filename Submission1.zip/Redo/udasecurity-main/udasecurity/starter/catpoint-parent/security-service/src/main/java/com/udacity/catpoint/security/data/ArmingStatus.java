package com.udacity.catpoint.security.data;

import java.awt.*;

/**
 * List of potential states the security system can use to describe how the system is armed.
 * Also contains metadata about what text and color is associated with the arming status.
 */
public enum ArmingStatus {
    // Three possible arming states, each associated with a description and color
    DISARMED("Disarmed", new Color(120, 200, 30)),
    ARMED_HOME("Armed | At Home", new Color(190, 180, 50)),
    ARMED_AWAY("Armed | Away", new Color(170, 30, 150));

    private final String description; // A description associated with the arming status
    private final Color color; // A color associated with the arming status

    // Constructor for the ArmingStatus enum
    ArmingStatus(String description, Color color) {
        this.description = description;
        this.color = color;
    }

    // Getter method to retrieve the description associated with the arming status
    public String getDescription() {
        return description;
    }

    // Getter method to retrieve the color associated with the arming status
    public Color getColor() {
        return color;
    }
}
