package com.udacity.catpoint.security.data;

import java.util.Set;

/**
 * Interface showing the methods our security repository will need to support.
 */
public interface SecurityRepository {
    // These are the methods that any implementation of the SecurityRepository interface must provide.

    /**
     * Adds a sensor to the security repository.
     *
     * @param sensor The sensor to be added.
     */
    void addSensor(Sensor sensor);

    /**
     * Removes a sensor from the security repository.
     *
     * @param sensor The sensor to be removed.
     */
    void removeSensor(Sensor sensor);

    /**
     * Updates the information of an existing sensor in the repository.
     *
     * @param sensor The updated sensor information.
     */
    void updateSensor(Sensor sensor);

    /**
     * Sets the alarm status of the security system.
     *
     * @param alarmStatus The new alarm status to be set.
     */
    void setAlarmStatus(AlarmStatus alarmStatus);

    /**
     * Sets the arming status of the security system.
     *
     * @param armingStatus The new arming status to be set.
     */
    void setArmingStatus(ArmingStatus armingStatus);

    /**
     * Retrieves a set of all sensors in the security repository.
     *
     * @return A set of sensors stored in the repository.
     */
    Set<Sensor> getSensors();

    /**
     * Retrieves the current alarm status of the security system.
     *
     * @return The current alarm status.
     */
    AlarmStatus getAlarmStatus();

    /**
     * Retrieves the current arming status of the security system.
     *
     * @return The current arming status.
     */
    ArmingStatus getArmingStatus();
}
