package com.udacity.catpoint.security.application;


public class CatpointApp {
    public static void main(String[] args) {
        // Create an instance of the CatpointGui class, which is responsible for the application's graphical user interface (GUI).
        CatpointGui gui = new CatpointGui();

        // Make the GUI window visible, allowing the user to interact with the application.
        gui.setVisible(true);
    }
}
