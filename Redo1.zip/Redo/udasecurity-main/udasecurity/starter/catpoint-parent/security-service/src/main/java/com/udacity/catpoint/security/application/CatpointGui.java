package com.udacity.catpoint.security.application;

import com.udacity.catpoint.image.service.FakeImageService;
import com.udacity.catpoint.image.service.ImageService;
import com.udacity.catpoint.security.data.MockSenario;
import com.udacity.catpoint.security.data.SecurityRepository;
import com.udacity.catpoint.security.service.SecurityService;
import net.miginfocom.swing.MigLayout;

import javax.swing.*;


public class CatpointGui extends JFrame {
    // Create and initialize various components and services needed for the application.

    // A security repository that simulates database storage for security data.
    private SecurityRepository securityRepository = new MockSenario();

    // An image service that provides image-related functionality.
    private ImageService imageService = new FakeImageService();

    // The main security service that handles security-related operations using the provided repositories and services.
    private SecurityService securityService = new SecurityService(securityRepository, imageService);

    // Panels for displaying information and interacting with the application.
    private DisplayPanel displayPanel = new DisplayPanel(securityService);
    private SensorPanel sensorPanel = new SensorPanel(securityService);
    private ControlPanel controlPanel = new ControlPanel(securityService, sensorPanel);
    private ImagePanel imagePanel = new ImagePanel(securityService);

    public CatpointGui() {
        // Set up the main JFrame for the application.

        // Define the initial location, size, and title of the JFrame.
        setLocation(100, 100);
        setSize(600, 850);
        setTitle("Very Secure App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create the main JPanel that will contain other subpanels using the MigLayout manager.
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new MigLayout());

        // Add subpanels to the main panel using the MigLayout constraints.
        mainPanel.add(displayPanel, "wrap"); // "wrap" here indicates a line break in the layout.
        mainPanel.add(imagePanel, "wrap");
        mainPanel.add(controlPanel, "wrap");
        mainPanel.add(sensorPanel);

        // Add the main panel to the content pane of the JFrame.
        getContentPane().add(mainPanel);
    }
}
