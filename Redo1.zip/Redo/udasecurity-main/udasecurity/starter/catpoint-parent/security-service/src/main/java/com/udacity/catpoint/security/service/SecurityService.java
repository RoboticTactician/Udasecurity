package com.udacity.catpoint.security.service;

import com.udacity.catpoint.security.data.Sensor;
import com.udacity.catpoint.image.service.ImageService;
import com.udacity.catpoint.security.application.StatusListener;
import com.udacity.catpoint.security.data.AlarmStatus;
import com.udacity.catpoint.security.data.ArmingStatus;
import com.udacity.catpoint.security.data.SecurityRepository;

import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Set;

/**
 * Service responsible for managing the security system. Handles changes in arming status, alarm status,
 * and sensor activations, and communicates with the repository and image service.
 */
public class SecurityService {

    private ImageService imageService;
    private SecurityRepository securityRepository;
    private Set<StatusListener> statusListeners = new HashSet<>();
    private boolean hasCat = false;

    public SecurityService(SecurityRepository securityRepository, ImageService imageService) {
        this.securityRepository = securityRepository;
        this.imageService = imageService;
    }

    /**
     * Sets the current arming status for the system. Changing the arming status
     * may update both the alarm status.
     *
     * @param armingStatus The new arming status to be set.
     */
    public void setArmingStatus(ArmingStatus armingStatus) {
        ArmingStatus currentArmingStatus = getArmingStatus();

        if (armingStatus == currentArmingStatus) {
            return;
        }

        // Handle arming status changes
        if (armingStatus == ArmingStatus.DISARMED) {
            setAlarmStatus(AlarmStatus.NO_ALARM);
        } else if (armingStatus == ArmingStatus.ARMED_HOME || armingStatus == ArmingStatus.ARMED_AWAY) {
            if (hasCat && armingStatus == ArmingStatus.ARMED_HOME) {
                setAlarmStatus(AlarmStatus.ALARM);
            }

            // Deactivate all sensors when arming
            getSensors().forEach(sensor -> changeSensorActivationStatus(sensor, false));
        }

        securityRepository.setArmingStatus(armingStatus);
    }

    /**
     * Register a StatusListener to receive alarm system updates.
     *
     * @param statusListener The listener to be registered.
     */
    public void addStatusListener(StatusListener statusListener) {
        statusListeners.add(statusListener);
    }

    public void removeStatusListener(StatusListener statusListener) {
        statusListeners.remove(statusListener);
    }

    /**
     * Change the alarm status of the system and notify all listeners.
     *
     * @param status The new alarm status to be set.
     */
    public void setAlarmStatus(AlarmStatus status) {
        securityRepository.setAlarmStatus(status);
        statusListeners.forEach(sl -> sl.notify(status));
    }

    /**
     * Change the activation status for the specified sensor and update alarm status if necessary.
     *
     * @param sensor The sensor to update.
     * @param active The new activation status for the sensor.
     */
    public void changeSensorActivationStatus(Sensor sensor, Boolean active) {
        Boolean previousActive = sensor.getActive();
        sensor.setActive(active);

        if (!previousActive && active) {
            handleSensorActivated();
        } else if (previousActive && !active) {
            handleSensorDeactivated();
        }

        securityRepository.updateSensor(sensor);
    }

    /**
     * Send an image to the SecurityService for processing. The service will analyze the image for cats and
     * update the alarm status accordingly.
     *
     * @param currentCameraImage The image to be processed.
     */
    public void processImage(BufferedImage currentCameraImage) {
        boolean catDetected = imageService.imageContainsCat(currentCameraImage, 50.0f);
        catDetected(catDetected);
    }

    public AlarmStatus getAlarmStatus() {
        return securityRepository.getAlarmStatus();
    }

    public Set<Sensor> getSensors() {
        return securityRepository.getSensors();
    }

    public void addSensor(Sensor sensor) {
        securityRepository.addSensor(sensor);
    }

    public void removeSensor(Sensor sensor) {
        securityRepository.removeSensor(sensor);
    }

    public ArmingStatus getArmingStatus() {
        return securityRepository.getArmingStatus();
    }

    /**
     * Handle sensor activation and update the alarm status.
     */
    private void handleSensorActivated() {
        if (getArmingStatus() != ArmingStatus.DISARMED) {
            AlarmStatus currentAlarmStatus = getAlarmStatus();

            if (currentAlarmStatus == AlarmStatus.NO_ALARM) {
                setAlarmStatus(AlarmStatus.PENDING_ALARM);
            } else if (currentAlarmStatus == AlarmStatus.PENDING_ALARM) {
                setAlarmStatus(AlarmStatus.ALARM);
            }
        }
    }

    /**
     * Handle sensor deactivation and update the alarm status.
     */
    private void handleSensorDeactivated() {
        AlarmStatus currentAlarmStatus = getAlarmStatus();

        if (currentAlarmStatus == AlarmStatus.PENDING_ALARM) {
            setAlarmStatus(AlarmStatus.NO_ALARM);
        }
    }

    /**
     * Internal method that handles cat detection and updates the alarm status.
     *
     * @param cat True if a cat is detected, otherwise false.
     */
    private void catDetected(Boolean cat) {
        hasCat = cat;
        ArmingStatus currentArmingStatus = getArmingStatus();
        AlarmStatus currentAlarmStatus = getAlarmStatus();

        if (cat && currentArmingStatus == ArmingStatus.ARMED_HOME) {
            setAlarmStatus(AlarmStatus.ALARM);
        } else if (!cat && getSensors().stream().noneMatch(Sensor::getActive)) {
            if (currentAlarmStatus == AlarmStatus.PENDING_ALARM) {
                setAlarmStatus(AlarmStatus.NO_ALARM);
            }
        }

        statusListeners.forEach(sl -> sl.catDetected(cat));
    }
}
