package com.udacity.catpoint.security.data;

import java.awt.*;

/**
 * List of potential states the alarm can have. Also contains metadata about what
 * text and color is associated with the alarm.
 */
public enum AlarmStatus {
    // Three possible alarm states, each associated with a description and color
    NO_ALARM("Good!", new Color(120, 200, 30)),
    PENDING_ALARM("Danger!", new Color(200, 150, 20)),
    ALARM("Alert!", new Color(250, 80, 50));

    private final String description; // A description associated with the alarm state
    private final Color color; // A color associated with the alarm state

    // Constructor for the AlarmStatus enum
    AlarmStatus(String description, Color color) {
        this.description = description;
        this.color = color;
    }

    // Getter method to retrieve the description associated with the alarm state
    public String getDescription() {
        return description;
    }

    // Getter method to retrieve the color associated with the alarm state
    public Color getColor() {
        return color;
    }
}
